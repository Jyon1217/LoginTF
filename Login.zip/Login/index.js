// 获取用户位置的函数
function getLocation() {
    return new Promise((resolve, reject) => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;
                    resolve({ latitude, longitude });
                },
                (error) => {
                    reject(error);
                }
            );
        } else {
            reject(new Error("Geolocation is not supported by this browser."));
        }
    });
}

// 处理登录逻辑的函数
async function handleLogin(event) {
    event.preventDefault(); // 阻止表单默认提交行为

    const userID = document.getElementById('userID').value;
    const password = document.getElementById('password').value;
    const statusMessage = document.getElementById('statusMessage');
    const locationDisplay = document.getElementById('locationDisplay');

    try {
        const location = await getLocation();
        const latitude = location.latitude;
        const longitude = location.longitude;

        // 显示经纬度信息
        locationDisplay.textContent = `Latitude: ${latitude}, Longitude: ${longitude}`;

        // 构造要发送到API的请求数据
        const requestData = {
            userID: userID,
            password: password,
            latitude: latitude,
            longitude: longitude
        };

        // 模拟API请求
        const response = await fakeAPICall(requestData);

        if (response.success) {
            statusMessage.textContent = "Successful Login!";
            statusMessage.style.color = "green";

            // 5秒后将页面背景变为蓝色，清空页面内容，并显示"Welcome"
            setTimeout(() => {
                clearLoginPage();
                displayWelcomeMessage();
            }, 5000);
        } else {
            statusMessage.textContent = "Login Failed!";
            statusMessage.style.color = "red";
        }
    } catch (error) {
        statusMessage.textContent = 'Unable to get your location: ' + error.message;
        statusMessage.style.color = "red";
    }
}

// 模拟API请求的函数
function fakeAPICall(data) {
    return new Promise((resolve) => {
        console.log("Sending data to API:", data);
        setTimeout(() => {
            resolve({ success: true }); // 模拟成功的API响应
        }, 1000); // 1秒的延迟模拟API响应时间
    });
}

// 清空登录页面并将背景变为蓝色
function clearLoginPage() {
    document.body.innerHTML = ''; // 清空整个页面内容
    document.body.style.backgroundColor = 'blue'; // 设置背景为蓝色
}

// 显示 "Welcome" 信息的函数
function displayWelcomeMessage() {
    const welcomeMessageHTML = `
        <div class="welcome-container">
            <h1>Welcome</h1>
        </div>
    `;
    document.body.innerHTML = welcomeMessageHTML; // 插入欢迎信息
    setTimeout(() => {
        displayMainPage(); // 显示主要页面
    }, 3000); // 3秒后显示主要页面
}

// 显示主要页面 (Check In/Out My Account 等)
function displayMainPage() {
    const mainPageHTML = `
        <div class="container">
            <h2>Check In/Out My Account</h2>
            <button>Check In</button>
            <button>Check Out</button>
            
            <h2>Check In/Out My Account New</h2>
            <button>Check In</button>
            <button>Check Out</button>
            <button>My State</button>

            <h2>Photo</h2>
            <div class="photo-upload">+</div>

            <p>My-Token: <span>flhq</span></p>

            <h2>All User</h2>
            <p>[]</p>
            <button>Login All</button>

            <h2>Check in All User</h2>
            <button>Check In All</button>
            <button>Check Out All</button>

            <button>Test Lot</button>
        </div>
    `;
    document.body.innerHTML = mainPageHTML; // 替换为主要页面内容
}
